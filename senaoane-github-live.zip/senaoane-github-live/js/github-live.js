
const DEFAULT_OWNER = "nmanakaza";
const DEFAULT_REPO = "senaoane-news-live";

async function loadLivePosts(){
  const statusEl = document.getElementById('live-status');
  try {
    let url = `data/posts.json`;
    const res = await fetch(url + '?t=' + Date.now());
    const posts = await res.json();
    statusEl.innerHTML = `✅ LIVE: Loaded ${posts.length} posts from GitHub • Last: ${posts[0]?.timestamp || 'now'}`;
    statusEl.className = "mt-3 text-xs bg-green-50 border border-green-200 p-2 rounded-xl";
    renderPosts(posts);
  } catch(e){
    statusEl.innerHTML = `⚠️ Offline/local mode: ${e.message}`;
    statusEl.className = "mt-3 text-xs bg-orange-50 border border-orange-200 p-2 rounded-xl";
    renderPosts([]);
  }
}

function renderPosts(posts){
  const feed = document.getElementById('posts-feed');
  if(!posts.length){
    feed.innerHTML = `<div class="bg-white border rounded-2xl p-4 text-sm text-gray-500">No posts yet. Be first to post live!</div>`;
    return;
  }
  feed.innerHTML = posts.map(p => `
    <div class="bg-white rounded-2xl border p-4">
      <div class="text-[10px] font-bold text-red-600">${p.category} • ${new Date(p.timestamp).toLocaleString()}</div>
      <div class="font-black mt-1">${p.title}</div>
      <div class="text-sm text-gray-700 mt-2">${p.body}</div>
      <div class="text-[11px] text-gray-500 mt-2">By ${p.author} • ${p.likes || 0} likes</div>
      <div class="mt-2 flex gap-2">
        <button onclick="sharePost(${p.id})" class="text-xs bg-[#25D366] text-white px-3 py-1 rounded-full font-bold">📢 Share to your WhatsApp friends and family.</button>
      </div>
    </div>
  `).join('');
}

async function postLiveToGitHub(){
  const owner = document.getElementById('gh-owner').value.trim();
  const repo = document.getElementById('gh-repo').value.trim();
  const token = document.getElementById('gh-token').value.trim();
  const author = document.getElementById('post-author').value.trim() || "Anonymous";
  const text = document.getElementById('post-text').value.trim();
  const responseEl = document.getElementById('post-response');
  
  if(!owner || !repo || !token){
    responseEl.className = "mt-3 text-xs p-3 rounded-xl border bg-red-50 border-red-200";
    responseEl.innerHTML = "❌ Fill owner, repo, and PAT.";
    responseEl.classList.remove('hidden');
    return;
  }
  if(!text){
    responseEl.className = "mt-3 text-xs p-3 rounded-xl border bg-red-50 border-red-200";
    responseEl.innerHTML = "❌ Write something!";
    responseEl.classList.remove('hidden');
    return;
  }

  responseEl.className = "mt-3 text-xs p-3 rounded-xl border bg-blue-50 border-blue-200";
  responseEl.innerHTML = "⏳ Posting to GitHub... getting SHA...";
  responseEl.classList.remove('hidden');

  try {
    const getUrl = `https://api.github.com/repos/${owner}/${repo}/contents/data/posts.json`;
    const getRes = await fetch(getUrl, {
      headers: { Authorization: `token ${token}`, Accept: 'application/vnd.github.v3+json' }
    });
    
    let currentPosts = [];
    let sha = null;
    
    if(getRes.ok){
      const data = await getRes.json();
      sha = data.sha;
      const content = atob(data.content.replace(/\n/g,''));
      currentPosts = JSON.parse(content);
      responseEl.innerHTML += `<br>✅ Got SHA: ${sha.slice(0,7)} • ${currentPosts.length} posts`;
    } else if(getRes.status === 404){
      responseEl.innerHTML += `<br>ℹ️ posts.json not found, will create`;
    } else {
      throw new Error(`GET failed: ${getRes.status} ${await getRes.text()}`);
    }

    const newPost = {
      id: Date.now(),
      title: text.slice(0,100),
      category: "LIVE • SUNDAY GAMES • " + new Date().toLocaleDateString(),
      body: text,
      author: author,
      timestamp: new Date().toISOString(),
      likes: 0,
      comments: []
    };
    currentPosts.unshift(newPost);

    const newContent = btoa(unescape(encodeURIComponent(JSON.stringify(currentPosts, null, 2))));
    const putRes = await fetch(getUrl, {
      method: 'PUT',
      headers: { Authorization: `token ${token}`, Accept: 'application/vnd.github.v3+json' },
      body: JSON.stringify({
        message: `New Sunday Games post by ${author}: ${text.slice(0,50)}`,
        content: newContent,
        sha: sha
      })
    });

    const putData = await putRes.json();
    if(!putRes.ok) throw new Error(`PUT failed: ${putRes.status} ${JSON.stringify(putData)}`);

    responseEl.className = "mt-3 text-xs p-3 rounded-xl border bg-green-50 border-green-200";
    responseEl.innerHTML = `
      ✅ <b>POSTED LIVE TO GITHUB!</b><br><br>
      <b>Commit:</b> ${putData.commit.sha.slice(0,7)}<br>
      <b>Message:</b> ${putData.commit.message}<br>
      <b>File:</b> data/posts.json<br>
      <b>Live URL:</b> <a href="${putData.content.html_url}" target="_blank" class="underline text-blue-600">${putData.content.html_url}</a><br>
      <b>Pages:</b> https://${owner}.github.io/${repo}/<br><br>
      Pages updates in ~30s. <button onclick="loadLivePosts()" class="mt-2 bg-black text-white px-3 py-1 rounded-full text-[11px]">🔄 Reload Live Feed</button>
    `;
    setTimeout(loadLivePosts, 1000);

  } catch(err){
    responseEl.className = "mt-3 text-xs p-3 rounded-xl border bg-red-50 border-red-200";
    responseEl.innerHTML = `❌ Error: ${err.message}`;
  }
}

function sharePost(id){
  const msg = `Senaoane Secondary Sunday Games time 11:00 first game till 5:00,Family is out day Vendors welcomed at a smola nyana fee.Come chill out man. Live post ID: ${id}`;
  window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
}

function shareSundayGames(){
  const message = `Senaoane Secondary Sunday Games time 11:00 first game till 5:00,Family is out day Vendors welcomed at a smola nyana fee.Come chill out man.\n\n📍 1105 Senaoane St\n🕒 Sunday 5 Oct • 11:00 till 17:00`;
  window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
}

window.addEventListener('DOMContentLoaded', loadLivePosts);
