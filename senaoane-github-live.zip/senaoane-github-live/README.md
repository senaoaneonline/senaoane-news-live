# Senaoane News - LIVE GitHub Edition
Makes the Sunday Games Post It REAL and LIVE via GitHub.

## How it works
1. Reads from data/posts.json on GitHub Pages (live data)
2. When posting, JS calls GitHub API to update data/posts.json
3. GitHub commits live -> site auto-updates
4. Response shows commit SHA

## Upload
- Create new repo e.g. senaoane-news-live
- Upload all files
- Enable Pages: Settings -> Pages -> main / root
- Create PAT: Settings -> Developer Settings -> PAT classic -> repo scope
